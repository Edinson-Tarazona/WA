$(document).ready(function(){

	var imgItems= $('.slider li').length;
	var imgPost= 1;
	


		$('.slider li img').delay(300).animate({
			opacity: 0.7
		}, 800);

	$('li .caption').delay(500).animate({
			opacity: 1,
			top: '20px',
			margin: 0 
	}, 1300);

	/* Efecto del submenu
	

	$(".menu .item-menu li a").mouseenter(function(){
    $(".submenu:has(ul)").css({
    	'visibility' : 'visible',
    	'display' : 'block',
    	'opacity' : '1'
    	});
  	});

  	$(".menu .item-menu li a").mouseleave(function(){
    $(".submenu:has(ul)").css({
    	'visibility' : 'hidden',
    	'display' : 'none',
    	'opacity' : '0'
    	});
  	});*/


	for(i=1 ; i<= imgItems; i++ ){

		$('.pagination').append('<li><span class="fas fa-circle"></span></li>');
	}



	$('.slider li').hide();//ocultamos las imagenes
	$('.slider li:first').show(); //mostramos la 1er img
	$('.pagination li:first').css({'color':'#fff'});




	//Ejecutamos todas las funciones

	$('.pagination li').click(pagination);
	$('.right span').click(nextSlider);
	//$('.left span').click(prevSlider);


		var timer = null;
	function startSetInterval() {
		    timer = setInterval(function(){
					nextSlider();
					},5000);

	}
	startSetInterval();


	// FUNCIONES #########################

	function pagination(){

		$('.slider .caption').css({
		opacity: 0,
		top: '60px'
		});

		$('.slider li img').css({opacity: 1});

		
	
		var  paginationPos = $(this).index() +1;
		$('.slider li').hide();
		$('.slider li:nth-child('+ paginationPos +')').fadeIn();
		
		$('.pagination li').css({'color' : 'rgba(0,0,0,.7)'});
		$(this).css({'color':'#fff'});

		

		imgPost= paginationPos
		$('li .caption').delay(300).animate({
			opacity: 1,
			top: '20px',
			margin: 0 
		}, 800);

		$('.slider li img').delay(300).animate({
			opacity: 0.7
		}, 1000);

		

	

	}


	function nextSlider(){


		$('.slider .caption').css({
			opacity: 0,
			top: '60px'
		});
		$('.slider li img').css({opacity: 1});

		
		if(imgPost >= imgItems){
			imgPost = 1
		

		}else{
			imgPost ++;
		}
		$('.pagination li').css({'color' : 'rgba(0,0,0,.7)'});/* 858585*/

		$('.pagination li:nth-child('+ imgPost +')').css({'color':'#fff'});

		$('.slider li').hide();
		$('.slider li:nth-child('+imgPost+')').fadeIn();


		$('li .caption').delay(300).animate({
			opacity: 1,
			top: '20px',
			margin: 0 
		}, 1000);

		$('.slider li img').delay(300).animate({
			opacity: 0.7
		}, 800);


	}



		


});